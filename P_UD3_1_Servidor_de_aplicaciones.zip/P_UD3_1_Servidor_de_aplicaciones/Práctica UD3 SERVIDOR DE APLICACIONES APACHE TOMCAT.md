Martín Estévez Aneiros
# 1. Funcionamiento de Tomcat en Windows con XAMPP

Se te facilita una máquina Windows, que ya viene con un Xampp operativo. Se te pedirá lo siguiente.

## 1.1. Arranque y configuración inicial

Configura para que arranque, y se pueda acceder a su página principal

**Instalar la extensión *Community Server Connectors***
![[extension.png]]

<div style="page-break-after: always;"></div>

**Crear un nuevo servidor**

![[crear_servidor.png]]

**Añadir un despliegue**
![[despliegue.png]]

**Mostrar en el servidor**
![[mostrar_servidor.png]]


<div style="page-break-after: always;"></div>

## 1.2 Acceso a opciones de gestión y administración

Realiza la configuración para que pueda acceder a server status, Manager App y Host Manager

**Modificar el fichero tomcat-users.xml
Añadir las siguientes líneas**

```xml
	<role rolename="admin-gui"/>
	<role rolename="manage-gui"/>
	<role rolename="manager-script"/>
	<role rolename="manager-jmx"/>
	<role rolename="manager-status"/>
	<user username="martinea" password="abc123." roles="admin-gui,manager-gui,manager-script,manager-jmx,manager-status"/>
```

![[manager.png]]

![[host-manager.png]]

![[status.png]]


<div style="page-break-after: always;"></div>

## 1.3 Ejemplos

Muestra su funcionamiento con alguno de los ejemplos disponibles

![[ejemplo.png]]

![[ejemplo_2.png]]


<div style="page-break-after: always;"></div>

## 1.4 Despliega tu propia aplicación web

Despliega un fichero Sample.war, y comprueba que puedes acceder a a la aplicación

![[sample.png]]


<div style="page-break-after: always;"></div>

## 1.5 Puerto de escucha

Cambia el puerto donde escucha por defecto de Tomcat

**Modificar el fichero server.xml**

```xml
	<Connector port="8181" protocol="HTTP/1.1"
		connectionTimeOut="20000"
		redirectPort="8080" />
```

![[cambio_puertos.png]]


<div style="page-break-after: always;"></div>

# 2. Instalación, configuración y funcionamiento de Tomcat en Linux

## 2.1 Instalación

Instala y realiza confguración para que pueda acceder a server status, Manager App y Host Manager

Instalar Java
```bash
sudo apt update  
sudo apt install openjdk-21-jdk
```

Descargar Tomcat y añadir usuario
```bash
curl -O https://dlcdn.apache.org/tomcat/tomcat-11/v11.0.4/bin/apache-tomcat-11.0.4.tar.gz
tar zxvf apache-tomcat-11.0.4.tar.gz
sudo mv apache-tomcat-11.0.4 /usr/libexec/tomcat11
sudo useradd -M -d /usr/libexec/tomcat11 tomcat  
sudo chown -R tomcat:tomcat /usr/libexec/tomcat11
```

Fichero de servicio
```bash
sudo nano /usr/lib/systemd/system/tomcat11.service
```

```
[Unit]  
Description=Apache Tomcat 11  
After=network.target  
  
[Service]  
Type=oneshot  
ExecStart=/usr/libexec/tomcat11/bin/startup.sh  
ExecStop=/usr/libexec/tomcat11/bin/shutdown.sh  
RemainAfterExit=yes  
User=tomcat  
Group=tomcat  
  
[Install]  
WantedBy=multi-user.target
```

Activar el servicio
```bash
sudo systemctl enable --now tomcat11  
sudo systemctl restart tomcat11
```

Crear cuenta
```bash
sudo nano /usr/libexec/tomcat11/conf/tomcat-users.xml
```

```xml
<role rolename="manager-gui"/>  
<role rolename="admin-gui"/>  
<user username="martinea" password="abc123.." roles="manager-gui,admin-gui"/>  
</tomcat-users>
```

![[principal_linux.png]]

Status
![[status.png]]

Manager App
![[manager_linux.png]]

Host Manager
![[host-manager_linux.png]]

<div style="page-break-after: always;"></div>

## 2.2. Desplieuge de aplicación web

Despliega un fichero Sample.war, y comprueba que puedes acceder a a la aplicación

![[sample_linux.png]]

![[sample_linux_2.png]]

<div style="page-break-after: always;"></div>

# 3. Securización

Configura para que el acceso sea seguro mediante certificados SSL, accediendo por HTTPS

Creación del keystore
```bash
sudo $JAVA_HOME/bin/keytool -genkey -alias tomcat -keyalg RSA -keysize 2048 -validity 365 -keystore /usr/libexec/tomcat11/conf/keystore.jks -storepass abc123..
```

![[keystore.png]]

```bash
sudo chown tomcat:tomcat /usr/libexec/tomcat11/conf/keystore.jks

sudo chmod 777 /usr/libexec/tomcat11/conf/keystore.jks

sudo nano /usr/libexec/tomcat11/conf/server.xml
```

```xml
<Connector port="8443" protocol="org.apache.coyote.http11.Http11NioProtocol" maxThreads="150" SSLEnabled="true">
    <SSLHostConfig>
	        <Certificate certificateKeystoreFile="/usr/libexec/tomcat11/conf/keystore.jks" certificateKeystorePassword="abc123.." type="RSA"/>
	</SSLHostConfig>
</Connector>
```

```bash
sudo systemctl restart tomcat11
```

![[certificado_linux.png]]

<div style="page-break-after: always;"></div>

# 4. Integración con un IDE

Raliza la integración de Tomcat con un IDE de tu elección (IntelliJ IDEA, Eclipse, Netbeans, Visual Studio Code,...)

Descargar Visual Studio Code
https://code.visualstudio.com/docs/setup/linux#_install-vs-code-on-linux

 ```bash
 sudo apt install /home/Downloads/code_1.108.1-1768404234_amd64.deb
 ```

Instalar Extension Pack for Java
![[extension_code.png]]

```
ctrl+shift+p => Maven: New project
Seleccionar arquitectura
Seleccionar versión
Nombre del proyecto
Seleccionar carpeta
```

![[proyecto_maven.png]]

Instalar extensión Community Server Connectors
![[extension_community_server_connectors.png]]

https://code.visualstudio.com/docs/java/java-tomcat-jetty

Crear un servidor Tomcat 11 y aceptar licencias
Seleccionar Server Actions y mostrar en navegador


<div style="page-break-after: always;"></div>

# 5. Cuestiones

**a) ¿Qué versión de Apache Tomcat instalarás dependiendo de tu versión de Java?**

  La versión más reciente de Tomcat que sea compatible con la de Java.  

**a.1) Y para la versión 8?**

  La versión más adecuada es la Apache Tomcat 9.x.

**a.2) Y para la versión 21?**

  La versión más adecuada es la Apache Tomcat 10.1.x.
  
**b) ¿Qué otros servidores de aplicaciones hay en el mercado? ¿Cuáles son software libre y cuales productos comerciales?**

Software libre:
- WildFly
- Jetty
- GlassFish

Productos comerciales:
- WebLogic Server (Oracle)
- WebSphere Application Server (IBM)
- JBoss EAP (Red Hat)
  
**c) Una de las cuestiones a tener en cuenta es el rendimiento de las aplicaciones. ¿Sabrías indicar alguna herramienta para pruebas de carga?**

  - Apache JMeter
  - Gatling
  - Locust

**d) Otra de las cuestiones a tener en cuenta es la monitorización del servidor de aplicaciones. ¿Sabrías indicarme alguna herramienta para monitorizar tomcat u otro servidor de aplicaciones? ¿Qué indicadores puede interesar monitorizar?**

Herramientas de monitorización:
- JConsole (Monitorización vía JMX)
- VisualVM (Monitorización vía JMX)
- Prometheus (Métricas y dashboards)
- Zabbix (Monitorización de infraestructura)

Interesa monitorizar el rendimiento, las peticiones al servidor, el estado de los procesos...
